---
title: "De la encuesta al diagnóstico: un post-mortem del proyecto Laguna Negra"
date: 2026-07-20
author: Karina Torralbo
tags: [gestión-de-proyectos, documentación, feedback, pymes, tesis]
---

# De la encuesta al diagnóstico: un post-mortem del proyecto "Laguna Negra"

## TL;DR
Durante el desarrollo del proyecto aplicado sobre la chocolatería [Laguna Negra](https://www.lagunanegra.com.ar/) (Ushuaia), la
etapa de campo (encuesta a 56 residentes de Río Grande) generó datos parcialmente inconsistentes que casi comprometen la
validación de la hipótesis. Aplicando un protocolo de post-mortem constructivo —enfocado en causas, no en culpas— pudimos
reconstruir el análisis, documentarlo de forma trazable con control de versiones y convertir el incidente en una mejora
metodológica permanente para el resto del trabajo.

---

## Contexto

El proyecto consistió en un diagnóstico estratégico y una propuesta de mejora operativa y comercial para **Laguna Negra**,
la chocolatería artesanal más austral del mundo (Ushuaia, fundada en 1989), en el marco de la Tecnicatura en Administración
de Empresas. El trabajo combinó herramientas clásicas de administración (FODA, PEST, 5 Fuerzas de Porter, benchmarking
estratégico frente a Rapanui, Moala y Benroth) con una etapa empírica: una encuesta a residentes de Río Grande, pensada
para validar la viabilidad de una nueva sucursal.

Como en cualquier proyecto con una etapa de recolección de datos y múltiples revisiones con el tutor (Prof. Barragán
Damián), el trabajo pasó por sucesivas versiones del documento, cada una con correcciones, reordenamientos de capítulos y
ajustes al marco teórico. Gestionar esas versiones sin perder trazabilidad —y sin generar fricción en las devoluciones del
tutor— fue, en la práctica, un problema de "ingeniería de proceso" tan real como el de cualquier equipo técnico.

## Problema

A mitad del análisis de la encuesta apareció una inconsistencia: el gráfico de "¿Visitó la Chocolatería Laguna Negra?"
mostraba 56 respuestas (66,1% sí / 33,9% no), pero las preguntas de seguimiento sobre la experiencia de compra (calidad de
atención, precio, aspectos a mejorar) solo tenían 44 o 45 respuestas. La diferencia no estaba documentada en ningún lado:
no sabíamos si se trataba de abandono del formulario, de un filtro condicional mal configurado en Google Forms, o de un
error de exportación al pasar los datos al documento.

Esto ponía en riesgo un punto central de la tesis: la brecha entre el "capital simbólico" de la marca (93,2% reconoce su
identidad fueguina, 100% la recomendaría) y su baja penetración comercial real en Río Grande (33,9% de visitas). Si la
base de esa brecha era una inconsistencia de datos, la conclusión perdía sustento.

## Acciones

Aplicamos, en versión adaptada a un trabajo de investigación, la misma lógica de un post-mortem técnico centrado en
aprendizaje y no en culpa:

1. **Reconstrucción de la línea de tiempo.** Revisamos cuándo se diseñó el formulario, cuándo se difundió y cuándo se
   exportaron los resultados, para ubicar en qué paso se perdieron respuestas.
2. **Recolección de evidencia.** Comparamos el archivo exportado de Google Forms contra las capturas usadas en el anexo,
   confirmando que el salto de 56 a 44/45 respuestas correspondía a un filtro condicional ("solo responde si visitó la
   chocolatería"), no a un error de carga de datos.
3. **Causa raíz sin buscar culpables.** La causa no fue un error de una persona, sino un diseño de encuesta que no
   explicitaba con claridad, en el propio informe, qué preguntas eran condicionales. Documentarlo así evitó que la
   revisión se convirtiera en una discusión sobre "quién se equivocó".
4. **Control de versiones del documento.** A partir de ese momento, cada revisión del trabajo (aportes del tutor,
   correcciones de estructura, incorporación del anexo) se guardó como una versión numerada con un registro breve de qué
   cambió y por qué, en lugar de sobrescribir el archivo anterior. Esto permitió volver atrás sin perder ninguna
   observación ya incorporada.
5. **Documentación clara para audiencia no técnica.** El hallazgo se explicó en el cuerpo de la tesis en lenguaje simple
   ("de los 56 encuestados, 44 respondieron por haber visitado el local"), evitando que un lector no vinculado al proceso
   metodológico interpretara mal los porcentajes.

## Aprendizajes

- **Separar el análisis del problema de la búsqueda de responsables** permitió resolver la inconsistencia en horas y no
  en discusiones. Esto es tan válido para un incidente de producción como para un formulario de Google Forms.
- **Versionar el documento, no solo "guardar como final_v2_ok"**, evitó perder trabajo y facilitó mostrarle al tutor
  exactamente qué había cambiado entre entregas.
- **Documentar el "porqué" de cada número**, no solo el número, hace que el trabajo sea auditable por cualquier lector,
  técnico o no.
- Una brecha de datos bien explicada (identidad fueguina fuerte, penetración comercial baja) terminó siendo, en lugar de
  un problema, uno de los hallazgos más útiles del diagnóstico para la propuesta de expansión a Río Grande.

## Reflexión: feedback radicalmente sincero

La devolución del tutor sobre el capítulo de benchmarking fue directa: señaló que el análisis comparativo estaba bien
estructurado, pero que las "recomendaciones para Laguna Negra" al final de esa sección repetían casi textualmente lo que
ya se decía en el capítulo de propuestas de mejora, sin aportar nada nuevo. Fue un comentario específico sobre el trabajo,
no sobre la persona, y venía acompañado de una sugerencia concreta ("o lo fusionás con las propuestas finales, o le das un
ángulo distinto acá").

Aplicar ese mismo criterio —ser directo y específico, mostrando al mismo tiempo que el objetivo es mejorar el resultado y
no señalar un error personal— fue lo que permitió, después, comunicar la inconsistencia de la encuesta sin que se leyera
como "la encuesta estuvo mal hecha", sino como "encontramos un punto a aclarar y así lo resolvimos". La misma estructura
Situación → Comportamiento → Impacto que se usa para dar feedback en una revisión de código sirvió, en este caso, para
redactar con calma la sección de "Interpretación general" de la encuesta.

---

*Control de versiones: este artículo documenta el proceso de un trabajo académico (no de software), por lo que el
"repositorio" al que se hace referencia abajo contiene el propio texto del post en Markdown versionado con Git, a modo de
evidencia del proceso de control de versiones aplicado a la actividad.*

## Checklist de publicación

- [x] Estructura problema-acción-impacto aplicada
- [x] Lenguaje claro, sin jerga innecesaria
- [x] Enlaces a evidencia (repositorio, commits)
- [x] Reflexión sobre feedback radicalmente sincero incluida
